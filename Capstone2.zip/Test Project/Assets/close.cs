﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class close : MonoBehaviour
{

    public GameObject window;

    public void w_close()
    {
        window.SetActive(false);
    }
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
}