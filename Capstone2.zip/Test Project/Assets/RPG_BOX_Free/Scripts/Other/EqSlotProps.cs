﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EqSlotProps : MonoBehaviour
{
    public GearMainType GearType;
}
