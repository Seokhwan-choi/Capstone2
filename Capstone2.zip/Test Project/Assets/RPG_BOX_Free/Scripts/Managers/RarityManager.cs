﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RarityManager : MonoBehaviour 
{
    public Color32[] ColorOfRarity = new Color32[5];//color of different rarity

}
